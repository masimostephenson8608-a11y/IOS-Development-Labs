//
//  ApiService.swift
//  SocialMediaApp
//
//  Created by Masimo Stephenson on 1/29/26.
//
import Foundation
import SwiftUI
import Observation

class ApiService: ApiServiceProtocol {
    
    enum ApiError: Error {
        case failedToBuildBaseURL, errorConvertingDatatoJSON, serverError, wholeFunctionFailed
        case failedHttpReponse
        case failedURLSession
    }
    
    func login(_ email: String, _ password: String) async throws -> signInResponse {
        // Creating Base URL
        guard let url = URL(string:"https://social-media-app.ryanplitt.com/auth/login") else {
            throw ApiError.failedToBuildBaseURL
        }
        
        // Making data that is ready to be converted into JSON
        let postData: [String:String] = [
            "email" : email,
            "password" : password
        ]
        
        let jsonEncoder = JSONEncoder()
        
        do {
            // Converting Data to JSON
            let beginData = try jsonEncoder.encode(postData)
            // MAKING REQUEST AND BUILDING THE BODY
            var request = URLRequest(url: url)
            
            request.httpMethod = "POST"
            
            request.httpBody = beginData
            
            // Setting header for URL request
            request.addValue("application/json", forHTTPHeaderField: "Content-type")
            
            let (data, response) = try await URLSession.shared.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse else { throw ApiError.serverError }
            
            if httpResponse.statusCode == 200 {
                let decoder = JSONDecoder()
                let results = try decoder.decode(signInResponse.self, from: data)
                print(results)
                return results
            } else {
                print("http response: \(httpResponse.statusCode)")
                print(String(data: data, encoding: .utf8) ?? "No body")
                throw ApiError.serverError
            }
            
        } catch {
            print(error)
        }
        throw ApiError.wholeFunctionFailed
    }
    
    func getProfile(userUUID: String, secret: String) async throws -> Profile {
        guard let baseURL = URL(string: "https://social-media-app.ryanplitt.com/user/\(userUUID)") else {
            //?userSecret=\(secret)
            throw ApiError.failedToBuildBaseURL
        }
        
        var components = URLComponents(string: "https://social-media-app.ryanplitt.com/user/\(userUUID)")
        
        let queryItems = [
            URLQueryItem(name: "userSecret", value: secret)
        ]
        
        components?.queryItems = queryItems
        
        let jsonEncoder = JSONEncoder()
        
        let body: [String : String] = [
            "userSecret" : secret
        ]
        
        do {
            var request = URLRequest(url: components!.url!)
            let data = try jsonEncoder.encode(body)
            
            
            request.httpMethod = "GET"
            
//            request.httpBody = data
//            
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let (responseData, response) = try await URLSession.shared.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse else { throw ApiError.failedHttpReponse }
            
            if httpResponse.statusCode == 200 {
                let decoder = JSONDecoder()
                let results = try decoder.decode(Profile.self, from: responseData)
                print(results)
                return results
            } else {
                print(httpResponse.statusCode)
                print(String(data: responseData, encoding: .utf8) ?? "No body")
                throw ApiError.serverError
            }
        } catch {
            print(error)
            throw error
        }
    }
    
    func addLike(to: Post) async throws {
        return
    }
    
    func fetchUserData() async throws -> User {
        User(id: "", firstName: "", lastName: "", userName: "", profilePicture: "", backgroundProfilePicture: "", bio: "", posts: [], techInterests: [])
    }
    
    func getAllPosts() async throws -> [Post] {
        return []
    }
}
